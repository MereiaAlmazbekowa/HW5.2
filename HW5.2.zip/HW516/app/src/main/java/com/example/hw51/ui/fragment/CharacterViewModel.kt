package com.example.hw51.ui.fragment

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.CreationExtras
import com.example.hw51.data.api.ApiService
import com.example.hw51.data.model.Character
import kotlinx.coroutines.launch

class CharacterViewModel(private val api: ApiService) : ViewModel() {

    private val _characters = MutableLiveData<List<Character>>()
    val characters: LiveData<List<Character>> get() = _characters

    private val _error = MutableLiveData<String>()
    val error: LiveData<String> get() = _error

    fun getCharacters() {
        viewModelScope.launch {
            try {
                val response = api.getCharacters()
                _characters.value = response.characters
            } catch (e: Exception) {
                _error.value = "Failed to load characters: ${e.message}"
            }
        }
    }
}


class CharacterViewModelFactory(private val api: ApiService) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>, extras: CreationExtras): T {
        return if (modelClass.isAssignableFrom(CharacterViewModel::class.java)) {
            CharacterViewModel(api) as T
        } else {
            throw IllegalArgumentException("Unknown ViewModel class")
        }
    }
}