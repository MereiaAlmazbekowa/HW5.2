package com.example.hw51.ui.fragment

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.hw51.data.api.ApiService
import com.example.hw51.interfaces.OnClickItem
import com.example.hw51.ui.adapter.CharacteristicAdapter
import com.example.hw51.data.model.Character
import com.example.hw51.databinding.FragmentCharacterBinding
import okhttp3.internal.platform.android.BouncyCastleSocketAdapter.Companion.factory
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class CharacterFragment : Fragment(), OnClickItem {

    private lateinit var adapter: CharacteristicAdapter
    private lateinit var viewModel: CharacterViewModel

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val binding = FragmentCharacterBinding.inflate(inflater, container, false)

        adapter = CharacteristicAdapter(onClick = this)
        binding.recyclerView.layoutManager = LinearLayoutManager(context)
        binding.recyclerView.adapter = adapter

        val apiService = Retrofit.Builder()
            .baseUrl("https://rickandmortyapi.com/api/")
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)

        val viewModelFactory = CharacterViewModelFactory(apiService)
        viewModel = ViewModelProvider(this, viewModelFactory)[CharacterViewModel::class.java]

        viewModel.getCharacters()
        viewModel.characters.observe(viewLifecycleOwner) { characters ->
            adapter.submitList(characters)
        }

        viewModel.error.observe(viewLifecycleOwner) { errorMessage ->
            Toast.makeText(requireContext(), errorMessage, Toast.LENGTH_SHORT).show()
        }

        return binding.root
    }

    override fun onClick(position: Character) {
        Toast.makeText(requireContext(), "Clicked: ${position.name}", Toast.LENGTH_SHORT).show()
    }
}